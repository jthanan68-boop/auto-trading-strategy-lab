"""Package marker for the paper trading engine."""

__version__ = "0.1.0"